#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int max(int a,int b)
{
    return a>b?a:b;
}
int min(int a,int b)
{
    return a<b?a:b;
}
int task2(char **a,char *cuv1,char *cuv2,int N,int *valmax)
{
    int i=0,poz,lg,lg1,lg2,ap=0,size;
    char *aux,*aux2,*p;
    for(i=0;i<N;i++)
    {
        ap=0;
        size=strlen(a[i]);
        aux=malloc( (strlen(a[i])+1) *sizeof(char));
        strcpy(aux,a[i]);
        p=strtok(aux," ',\"?!");
            while(p!=NULL)
            {
                if(strcmp(p,cuv1)==0)
                {
                    lg=strlen(a[i]);
                    lg1=strlen(cuv1);
                    lg2=strlen(cuv2);
                    poz=p-aux-ap*(strlen(cuv1)-strlen(cuv2));
                    if(lg2>=lg1)
                        {
                            size+=(lg2-lg1);
                            if(size>14000)
                            {
                                aux2=realloc(a[i],size*sizeof(char));
                                if(aux2!=NULL)
                                a[i]=aux2; //in cazul in care cuvantul cu care trebuie sa inlocuiesc are lungimea mai mare decat a celui deja existent, realoc memorie in plus cu diferenta dintre cuvinte
                            }
                            memmove(a[i]+poz+max(lg2-lg1,0),a[i]+poz,lg-poz+1);
                            memcpy(a[i]+poz,cuv2,lg2);
                        }
                    else
                         {
                            memmove(a[i]+poz+lg2,a[i]+poz+lg1,lg-poz-lg1);
                            memcpy(a[i]+poz,cuv2,lg2);
                            lg-=(lg1-lg2);
                            a[i][lg]='\0';
                         }
                    ap++;
                }
                p=strtok(0," ',\"?!");
            }
        if(aux!=NULL)
            free(aux);
        if(size>*valmax) *valmax=size;
    }
    return 0;
}
int task1(char **a,char *cuv,int N)
{
    int s=0,i;
    char *aux,*p;
    for(i=0;i<N;i++)
    {
        aux=malloc((strlen(a[i])+1)*sizeof(char));
        strcpy(aux,a[i]);
        p=strtok(aux," ',\"?!");
        while( p != NULL)
        {
            if(strcmp(p,cuv)==0)
                s++;
            p=strtok(NULL, " ',\"?!");
        }
        if(aux != NULL)
            free(aux);
    }
    return s;
}
int main()
{
    int N,M,i,j,op,s=0,K,size=12000;
    int *valmax;
    char **a,*cuv,*cuv1,*cuv2;
    valmax=calloc(1,sizeof(int));
    *valmax=0;
    scanf("%d",&N);
    getchar();
    a=malloc(N*sizeof(int));
    for(i=0;i<N;i++)
        {
            a[i]=malloc(14000*sizeof(char));
            fgets(a[i],14000,stdin);
            a[i][strlen(a[i])-1]='\0';
        }
    scanf("%d",&M);

    for(i=0;i<M;i++)
    {
        s=0;
        scanf("%d",&op);
        getchar();
        if(op==1)
        {
            cuv=malloc(12000*sizeof(char));
            scanf("%s",cuv);
            s=task1(a,cuv,N);
            printf("%d\n",s);
            if(cuv!=NULL)
                free(cuv);
        }
        else if(op==2)
            {
                cuv1=malloc(12000*sizeof(char));
                cuv2=malloc(12000*sizeof(char));
                scanf("%s",cuv1);
                scanf("%s",cuv2);
                task2(a,cuv1,cuv2,N,valmax);
                free(cuv1);
                free(cuv2);
                for(j=0;j<N;j++)
                    printf("%s\n",a[j]);
            }
            else {
                    char *aux,*p,*p2,*p3;
                    int poz,lg,ap=0;
                    scanf("%d",&K);
                    for(j=0;j<N;j++)
                   {
                        aux=malloc((strlen(a[j])+1) * sizeof(char));
                        p2=malloc((strlen(a[j])+1) * sizeof(char));
                        p3=malloc((strlen(a[j])+1) * sizeof(char));
                        strcpy(aux,a[j]);
                        ap=0;
                        p=strtok(aux," ',\"?!");
                        while (p != NULL)
                        {
                            strcpy(p2,p);
                            lg=strlen(p);
                            memcpy(p3,p2+lg-(K%strlen(p)),K%lg);
                            memmove(p2+K%strlen(p),p2,lg-K%strlen(p));
                            memcpy(p2,p3,K%strlen(p));
                            memcpy(a[j]+(p-aux),p2,strlen(p)); //aici am realizat permutarea fiecarui cuvant
                            p=strtok(0," ',\"?!");
                        }
                        if(p2!=NULL)
                            free(p2);
                        if(p3!=NULL)
                            free(p3);
                        if(aux!=NULL)
                            free(aux);
                   }
                   for(j=0;j<N;j++)
                    printf("%s\n",a[j]);
                }
    }
    for(i=0;i<N;i++)
        if(a[i]!=NULL)
            free(a[i]);
    if(a!=NULL)
        free(a);
    if(valmax!=NULL)
        free(valmax);
    return 0;
}
