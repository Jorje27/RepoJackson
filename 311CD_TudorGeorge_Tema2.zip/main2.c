#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef struct ls { char **list;
                    int *ap;
                    int nr;
               } ls;
//folosim cate o lista pentru fiecare text si un pointer catre aparitiile fiecarui cuvant in lista dupa extragere.
int freee(char **a,int N)
{
    int i;
    for(i=0;i<N;i++)
            free(a[i]);
    free(a);
}
char ** read(int N,char **a)
{
    int i;
    a=malloc(12000*sizeof(char*));
    char *s=malloc(12000*sizeof(char));
    for(i=0;i<N;i++)
        {
            fgets(s,12000,stdin);
            a[i]=malloc( (strlen(s)+1)*sizeof(char));
            strcpy(a[i],s);
            a[i][strlen(a[i])-1]='\0';
        }
    free(s);
    return a;
}
ls * aloca(ls *text)
{
    text=malloc(sizeof(ls));

    text->nr=0;

    text->ap=calloc(12000,sizeof(int));
    text->list=malloc(12000*sizeof(char*));
    return text;
}
int frei(ls *t)
{
    int i;
    for(i=0;i<(t->nr);i++)
         free(t->list[i]);
    free(t->ap);
    free(t->list);
    free(t);
}
int apar(char *p,int *poz,ls *t)
{
    int i;int gasit=0;
    for(i=0;i<t->nr;i++)
            if(strcmp(t->list[i],p)==0)
                { *poz=i; gasit=1; }
    return gasit;
}
char ** extract(int N,char **text, ls *t)
{
    char *s,*p;int *poz=calloc(1,sizeof(int));
    int i;
    for(i=0;i<N;i++)
    {
        p=strtok(text[i],"? '!/,.\"");
        while(p != NULL)
        {
            if(apar(p,poz,t) == 0 )
                {
                    t->list[t->nr]=malloc(12000*sizeof(char));
                    strcpy(t->list[t->nr],p);
                    t->ap[t->nr]=1;
                    (t->nr)++;
                }
            else t->ap[*poz]++;
            p=strtok(0,"? '!/,.\"");

        }
    }
    free(poz);
   //printf("Extragerea a avut loc cu succes\n");
    return 0;
}
int maxim(int a,int b)
{
    return a>b?a:b;
}
int minim(int a,int b)
{
    return a<b?a:b;
}
int abs(int x)
{
    return x>0?x:(0-x);
}
int sort(ls *t)
{
    int o=1,i=0,aux_ct;
    char *s,*aux;
    s=malloc(12000*sizeof(char));

    while(o)
    {
        o=0;
        for(i=0;i<(t->nr)-1;i++)
            if(t->ap[i]<t->ap[i+1])
                {
                    aux=realloc(s,1+maxim(strlen(t->list[i]),strlen(t->list[i+1])));
                    if(aux!=NULL)
                    s=aux;
                    strcpy(s,t->list[i]);
                    strcpy(t->list[i],t->list[i+1]);
                    strcpy(t->list[i+1],s);

                    aux_ct=t->ap[i];
                    t->ap[i]=t->ap[i+1];
                    t->ap[i+1]=aux_ct;
                    o=1;
                }
            else if(t->ap[i] == t->ap[i+1])
                    if(strcmp(t->list[i],t->list[i+1])>0)
                            {
                                aux=realloc(s,1+maxim(strlen(t->list[i]),strlen(t->list[i+1])));
                                if(aux!=NULL)
                                s=aux;
                                strcpy(s,t->list[i]);
                                strcpy(t->list[i],t->list[i+1]);
                                strcpy(t->list[i+1],s);
                                aux_ct=t->ap[i];
                                t->ap[i]=t->ap[i+1];
                                t->ap[i+1]=aux_ct;
                                o=1;
                            }

    }
    free(s);
    //printf("S-a sortat cu succes\n");
    return 0;
}
int dist(char *a,char *b)
{
    int d=0,i;
    int lg1=strlen(a);
    int lg2=strlen(b);
// in continuare parcurgem cuvantul mai mic, urmand ca restului de caractere din cuvantul mai mare sa ii aplicam direct abs
    if(lg1>lg2)
        {
            for(i=0;i<lg2;i++)
                    d+=(abs(a[i]-b[i]));
            for(i=lg2;i<lg1;i++)
                d+=abs(a[i]);
        }
    else {
            for(i=0;i<lg1;i++)
                d+=(abs(a[i]-b[i]));    
            for(i=lg1;i<lg2;i++)
       		d+=abs(b[i]);
         }

    return d;
}
int sim(ls *t1,ls *t2)
{
    int suma=0,i;
    for(i=0;i<minim(t1->nr,t2->nr);i++)
            suma=suma+( (t1->ap[i]+t2->ap[i]) * dist(t1->list[i],t2->list[i]) );
    return suma;
}
int main()
{
    int N,M,grad=0;
    char **text1,**text2,*aux;
    char *s;
    scanf("%d\n",&N);
    text1=read(N,text1);
    scanf("%d\n",&M);
    text2=read(M,text2);
    ls *t1,*t2;

    t1=aloca(t1);
    extract(N,text1,t1);

    t2=aloca(t2);
    extract(M,text2,t2);

    sort(t1);
    sort(t2);

    grad=grad+100*abs((t1->nr)-(t2->nr))+sim(t1,t2);
    freee(text1,N);
    freee(text2,M);
    //S-a eliberat memoria textelor
    aux=realloc(t1->ap,t1->nr*sizeof(int));
    t1->ap=aux;
    aux=realloc(t2->ap,t2->nr*sizeof(int));
    t2->ap=aux;
    //S-a realocat memoria pentru aparitii
    frei(t1);
        frei(t2);
    //S-a eliberat memoria listelor
    printf("%d",grad);
    return 0;
}
